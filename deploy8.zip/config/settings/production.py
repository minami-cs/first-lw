from .base import *

DEBUG = False
ALLOWED_HOSTS = ["myfirsthome-env.eba-bp3f3gar.ap-northeast-2.elasticbeanstalk.com"]